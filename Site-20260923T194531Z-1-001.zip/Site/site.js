

document.addEventListener("DOMContentLoaded", () => {

mensagemBoasVindas();

efeitoScroll();

animarCards();

validarFormulario();

selecionarMes();

});

/* ===========================
BOAS-VINDAS
=========================== */

function mensagemBoasVindas(){

console.log("Bem-vindo ao Nutrir & Aprender");

}

/* ===========================
ANIMAÇÃO DOS CARDS
=========================== */

function animarCards(){

const cards=document.querySelectorAll(".card");

cards.forEach(card=>{

card.addEventListener("mouseenter",()=>{

card.style.transform="translateY(-12px)";

});

card.addEventListener("mouseleave",()=>{

card.style.transform="translateY(0px)";

});

});

}

/* ===========================
SCROLL SUAVE
=========================== */

function efeitoScroll(){

const links=document.querySelectorAll('a[href^="#"]');

links.forEach(link=>{

link.addEventListener("click",(e)=>{

e.preventDefault();

const destino=document.querySelector(link.getAttribute("href"));

destino.scrollIntoView({

behavior:"smooth"

});

});

});

}

/* ===========================
FORMULÁRIO
=========================== */

function validarFormulario(){

const form=document.querySelector("form");

form.addEventListener("submit",(e)=>{

e.preventDefault();

const nome=form.querySelector("input").value;

const email=form.querySelector('input[type="email"]').value;

const texto=form.querySelector("textarea").value;

if(nome==="" || email==="" || texto===""){

alert("Preencha todos os campos.");

return;

}

alert("Obrigado! Sua sugestão foi enviada com sucesso.");

form.reset();

});

}

/* ===========================
CARDÁPIO MENSAL
=========================== */

function selecionarMes(){

const meses=document.querySelectorAll(".calendario button");

meses.forEach(botao=>{

botao.addEventListener("click",()=>{

meses.forEach(item=>{

item.style.background="white";
item.style.color="#333";

});

botao.style.background="#6AA84F";
botao.style.color="white";

alert("Cardápio de " + botao.innerText + " carregado.");

});

});

}

/* ===========================
BOTÃO VOLTAR AO TOPO
=========================== */

const voltarTopo=document.createElement("button");

voltarTopo.innerHTML="⬆";

voltarTopo.style.position="fixed";
voltarTopo.style.right="30px";
voltarTopo.style.bottom="30px";
voltarTopo.style.width="55px";
voltarTopo.style.height="55px";
voltarTopo.style.borderRadius="50%";
voltarTopo.style.border="none";
voltarTopo.style.background="#F28C28";
voltarTopo.style.color="white";
voltarTopo.style.fontSize="22px";
voltarTopo.style.cursor="pointer";
voltarTopo.style.display="none";
voltarTopo.style.boxShadow="0 8px 20px rgba(0,0,0,.2)";

document.body.appendChild(voltarTopo);

window.addEventListener("scroll",()=>{

if(window.scrollY>350){

voltarTopo.style.display="block";

}else{

voltarTopo.style.display="none";

}

});

voltarTopo.addEventListener("click",()=>{

window.scrollTo({

top:0,

behavior:"smooth"

});

});

/* ===========================
REFEIÇÃO DO DIA
=========================== */

const refeicoes = {

Segunda:"Arroz, Feijão, Frango",

Terça:"Macarrão",

Quarta:"Omelete",

Quinta:"Polenta",

Sexta:"Peixe"

};

const hoje=new Date();

const dias=["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];

const diaAtual=dias[hoje.getDay()];

if(refeicoes[diaAtual]){

console.log("Hoje será servido: "+refeicoes[diaAtual]);

}

const loginForm = document.querySelector("#loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", function (e) {

        e.preventDefault();

        const email = document.querySelector("#email").value;
        const senha = document.querySelector("#senha").value;

        if (email !== "" && senha !== "") {

            localStorage.setItem("usuarioLogado", "true");

            alert("Login realizado com sucesso!");

            window.location.href = "index.html";
        }

    });

}